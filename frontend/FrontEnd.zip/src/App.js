import logo from "./logo.svg";
import "./App.css";
import FormDetalis from "./Component/FormDetalis";

function App() {
  return (
    <div className="App">
      <FormDetalis />
    </div>
  );
}

export default App;
